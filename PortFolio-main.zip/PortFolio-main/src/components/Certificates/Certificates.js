import React, { useState } from "react";
import { Container, Row, Col, Card, Collapse, Button } from "react-bootstrap";
import Particle from "../Particle";

const certificates = [
    {
        title: "Software Developer",
        issuer: "Personal & Team Projects",
        date: "Ongoing",
        link: "",
        description: "Built various end-to-end applications including portfolio sites, admin dashboards, and APIs using modern JavaScript frameworks and cloud services."
    },
    {
        title: "Freelancer",
        issuer: "Clients via Upwork & Personal Network",
        date: "2021 – Present",
        link: "",
        description: "Delivered custom website and application solutions for multiple clients, handling UI/UX, responsive design, backend integration, and deployment."
    },
    {
        title: "Frontend Developer",
        issuer: "Independent & Team-Based Projects",
        date: "2021 – Present",
        link: "",
        description: "Developed responsive user interfaces using React.js, Bootstrap, and Tailwind CSS with attention to accessibility, animations, and SEO-friendly markup."
    },
    {
        title: "Backend Developer",
        issuer: "Self-Projects & Open Source",
        date: "2021 – Present",
        link: "",
        description: "Created scalable backend services using Node.js, Express, MongoDB, PostgreSQL, and implemented REST APIs with authentication, logging, and role-based access."
    },
    {
        title: "Full-Stack Developer",
        issuer: "Project-Based Learning",
        date: "2022 – Present",
        link: "",
        description: "Integrated full-stack solutions combining React (frontend) and Node.js/Express (backend), including payment systems, form submissions, and file handling."
    },
    {
        title: "React Developer",
        issuer: "Self-Learning & Projects",
        date: "2022 – Present",
        link: "",
        description: "Built multiple dynamic web apps using React.js including routing, hooks, state management with Redux, and integration with APIs."
    },
    {
        title: "UI/UX Designer",
        issuer: "Freelance & Personal Projects",
        date: "2021 – Present",
        link: "",
        description: "Designed clean, user-friendly interfaces in Figma and Adobe XD, focusing on accessibility, responsiveness, and usability principles."
    },
    {
        title: "API Integration Specialist",
        issuer: "Freelance Projects",
        date: "2022 – Present",
        link: "",
        description: "Integrated REST APIs, handled authentication, error handling, and asynchronous data flows in frontend apps."
    },
    {
        title: "Open Source Contributor",
        issuer: "GitHub Community",
        date: "2023 – Present",
        link: "",
        description: "Contributed to open-source repositories by fixing bugs, improving documentation, and participating in pull requests and discussions."
    },
    {
        title: "WordPress Developer",
        issuer: "Anudip Foundation",
        date: "2020",
        link: "https://drive.google.com/file/d/1cERnkoQe7-6ck2elb3_xU2_DFrK6Tx5d/preview",
        description: "Completed a professional course on WordPress development, covering themes, plugins, and CMS architecture."
    },
    {
        title: "Cyber Security & Ethical Hacking",
        issuer: "Anudip",
        date: "Feb 2022",
        link: "https://drive.google.com/file/d/1QH85jL2JuVI2_96SpAlAXNdNsZLWRa4K/preview",
        description: "Trained in ethical hacking, network security, and real-world attack prevention strategies."
    },
    {
        title: "C Program",
        issuer: "Pride Institute",
        date: "Jan 2022",
        link: "https://drive.google.com/file/d/1e86amkdHFmDtsSShoQzR7lsPpFLo546T/preview",
        description: "Learned fundamental C programming concepts including loops, arrays, and data structures."
    },
    {
        title: "C++ Program",
        issuer: "Government Certified Program",
        date: "Jan 2022",
        link: "https://drive.google.com/file/d/1eJ_P-naW2eCPEp8cMRYGC4DRSUHHUyEr/preview",
        description: "Built object-oriented applications using C++ classes, inheritance, and polymorphism."
    },
    {
        title: "MySQL",
        issuer: "Pride Institute",
        date: "May 2022",
        link: "https://drive.google.com/file/d/1z6GvLtjXI-2KER4K1U9qqOPHuZnQRi38/preview",
        description: "Hands-on SQL queries, joins, and database design using MySQL."
    },
    {
        title: "HTML & CSS",
        issuer: "Pride Institute",
        date: "May 2022",
        link: "https://drive.google.com/file/d/1TM3QvResIq59-FORHeWFnU46rJozKRK3/preview",
        description: "Built responsive web pages using semantic HTML and modern CSS techniques."
    },
    {
        title: "Networking and CCNA",
        issuer: "Anudip",
        date: "Nov 2020",
        link: "https://drive.google.com/file/d/1qSeRe3gtrTTOumEJCyh0_E5Qukwql10C/preview",
        description: "Gained foundational knowledge of networking concepts, TCP/IP, routing, switching, and Cisco CCNA fundamentals including hands-on configuration of network devices."
    },
    {
        title: "Forensic Investigation Quiz",
        issuer: "IFS (International Forensic Science)",
        date: "Jun 2020",
        link: "https://drive.google.com/file/d/1qSeRe3gtrTTOumEJCyh0_E5Qukwql10C/preview",
        description: "Participated in a certified quiz on forensic investigation, assessing knowledge in digital forensics, evidence handling, and cybercrime investigation basics."
    },
];

function Certificates() {
  const [openIndex, setOpenIndex] = useState(null);

  const togglePreview = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  // Separate entries with and without link
  const realCertificates = certificates.filter(cert => cert.link);
  const experiences = certificates.filter(cert => !cert.link);

  return (
    <Container fluid className="project-section">
      <Particle />
      <Container>
        {/* Certificate Section */}
        <h2 className="text-center mb-4 text-white">Certificates</h2>
        <p className="text-center text-white mb-5">
          A showcase of official certifications demonstrating technical proficiency and continuing education.
        </p>
        <Row>
          {realCertificates.map((cert, index) => (
            <Col md={6} lg={4} key={index} className="mb-4">
              <Card className="h-100 shadow-sm">
                <Card.Body>
                  <Card.Title className="fw-bold">{cert.title}</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">{cert.issuer}</Card.Subtitle>
                  <Card.Text><small>{cert.date}</small></Card.Text>
                  <p className="mt-2">{cert.description}</p>

                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => togglePreview(index)}
                    aria-expanded={openIndex === index}
                  >
                    {openIndex === index ? "Hide Preview" : "View Certificate"}
                  </Button>
                  <Collapse in={openIndex === index}>
                    <div className="mt-3">
                      <iframe
                        src={cert.link}
                        title={cert.title}
                        style={{
                          width: "100%",
                          height: "300px",
                          border: "1px solid #ddd",
                          borderRadius: "8px",
                        }}
                      />
                    </div>
                  </Collapse>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>

        {/* Experience Section */}
        <h2 className="text-center mb-4 text-white mt-5">Roles & Experience</h2>
        <p className="text-center text-white mb-5">
          These roles highlight practical skills, project involvement, and professional development beyond formal certification.
        </p>
        <Row>
          {experiences.map((exp, index) => (
            <Col md={6} lg={4} key={index} className="mb-4">
              <Card className="h-100 shadow-sm">
                <Card.Body>
                  <Card.Title className="fw-bold">{exp.title}</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">{exp.issuer}</Card.Subtitle>
                  <Card.Text><small>{exp.date}</small></Card.Text>
                  <p className="mt-2">{exp.description}</p>
                  <span className="badge bg-secondary mt-2">Experience</span>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </Container>
  );
}

export default Certificates;
