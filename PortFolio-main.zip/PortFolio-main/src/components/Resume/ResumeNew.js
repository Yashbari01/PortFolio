import React, { useState, useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Particle from "../Particle";
import pdf from "../../Assets/../Assets/YashBariResume.pdf";
import { AiOutlineDownload } from "react-icons/ai";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/esm/Page/AnnotationLayer.css";
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

function ResumeNew() {
  const [width, setWidth] = useState(1200);

  useEffect(() => {
    setWidth(window.innerWidth);
  }, []);


  return (
    <div>
      <Container fluid className="resume-section">
        <Particle />

               {/* Top Download Button */}
        <Row className="justify-content-center mb-4 mt-3">
          <Button variant="primary" href={pdf} target="_blank" style={{ maxWidth: "250px" }}>
            <AiOutlineDownload /> &nbsp;Download CV
          </Button>
        </Row>

 {/* Intro */}
        <Row className="text-center text-white">
          <Col md={10} className="mx-auto mb-4">
            <h2 className="mb-3">My Resume</h2>
            <p>
              Here's my latest resume detailing my experience, skills, and accomplishments as a full-stack developer. You can download the PDF or preview it below.
            </p>
          </Col>
        </Row>

        {/* Highlights */}
        <Row className="justify-content-center text-white mb-5">
          <Col md={10}>
            <h4 className="mb-3">Key Highlights</h4>
           <ul className="list-unstyled">
  <li>✅ Proficient in React, Node.js, Express, MongoDB</li>
  <li>✅ Experience with RESTful APIs, JWT authentication, and middleware integration</li>
  <li>✅ Freelance experience delivering responsive web apps for real-world clients</li>
  <li>✅ Contributor to open-source projects on GitHub</li>
  <li>✅ Strong problem-solving and debugging skills</li>
  <li>✅ Familiar with deployment tools like Vercel, Netlify, and Render</li>
  <li>✅ Knowledge of Git, GitHub workflows, and version control best practices</li>
  <li>✅ Focused on performance optimization and responsive UI/UX design</li>
  <li>✅ Ability to work independently and collaboratively in Agile teams</li>
  <li>✅ Continuous learner with hands-on experience in multiple tech stacks</li>
</ul>
          </Col>
        </Row>

        <Row className="resume">
          <Document file={pdf} className="d-flex justify-content-center">
            <Page pageNumber={1} scale={width > 786 ? 1.7 : 0.6} />
          </Document>
        </Row>

        <Row style={{ justifyContent: "center", position: "relative" }}>
          <Button
            variant="primary"
            href={pdf}
            target="_blank"
            style={{ maxWidth: "250px" }}
          >
            <AiOutlineDownload />
            &nbsp;Download CV
          </Button>
        </Row>
      </Container>
    </div>
  );
}

export default ResumeNew;
