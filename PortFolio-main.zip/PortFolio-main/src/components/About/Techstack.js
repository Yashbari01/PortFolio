import React from "react";
import { Col, Row, OverlayTrigger, Tooltip } from "react-bootstrap";
import { CgCPlusPlus } from "react-icons/cg";
import {
  DiJavascript1,
  DiReact,
  DiNodejs,
  DiMongodb,
  DiPython,
  DiGit,
  DiJava,
} from "react-icons/di";
import {
  SiMysql,
  SiPhp,
  SiHtml5,
  SiCss3,
  SiNextdotjs,
  SiSolidity,
  SiWordpress,
  SiPostgresql,
  SiRedux,
  SiTypescript,
  SiTailwindcss,
  SiBootstrap,
  SiFirebase,
  SiExpress,
  SiGraphql,
  SiDjango,
  SiVite,
  SiPrisma,
  SiGnubash,
  SiCisco,
} from "react-icons/si";
import { TbBrandGolang } from "react-icons/tb";

const techs = [
  { icon: <DiReact />, name: "React.js" },
  { icon: <SiNextdotjs />, name: "Next.js" },
  { icon: <SiRedux />, name: "Redux" },
  { icon: <DiNodejs />, name: "Node.js" },
  { icon: <SiExpress />, name: "Express.js" },
  { icon: <DiJavascript1 />, name: "JavaScript" },
  { icon: <SiTypescript />, name: "TypeScript" },
  { icon: <DiPython />, name: "Python" },
  { icon: <SiDjango />, name: "Django" },
  { icon: <DiJava />, name: "Java" },
  { icon: <CgCPlusPlus />, name: "C++" },
  { icon: <SiPhp />, name: "PHP" },
  { icon: <SiHtml5 />, name: "HTML5" },
  { icon: <SiCss3 />, name: "CSS3" },
  { icon: <SiTailwindcss />, name: "Tailwind CSS" },
  { icon: <SiBootstrap />, name: "Bootstrap" },
  { icon: <SiFirebase />, name: "Firebase" },
  { icon: <DiMongodb />, name: "MongoDB" },
  { icon: <SiMysql />, name: "MySQL" },
  { icon: <SiPostgresql />, name: "PostgreSQL" },
  // { icon: <SiPrisma />, name: "Prisma ORM" },
  { icon: <DiGit />, name: "Git" },
  { icon: <SiWordpress />, name: "WordPress" },
  // { icon: <SiGraphql />, name: "GraphQL" },
  // { icon: <TbBrandGolang />, name: "Golang" },
  // { icon: <SiSolidity />, name: "Solidity" },
  { icon: <SiVite />, name: "Vite" },
  { icon: <SiGnubash />, name: "Bash" },
  { icon: <SiCisco />, name: "Networking & CCNA" },
];

function Techstack() {
  return (
    <Row style={{ justifyContent: "center", paddingBottom: "50px" }}>
      {techs.map((tech, index) => (
        <Col xs={4} md={2} className="tech-icons" key={index}>
          <OverlayTrigger
            placement="top"
            overlay={<Tooltip id={`tooltip-${index}`}>{tech.name}</Tooltip>}
          >
            <span>{tech.icon}</span>
          </OverlayTrigger>
        </Col>
      ))}
    </Row>
  );
}

export default Techstack;
