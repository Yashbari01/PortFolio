import React from "react";
import Card from "react-bootstrap/Card";
import { ImPointRight } from "react-icons/im";

function AboutCard() {
  return (
    <Card className="quote-card-view">
      <Card.Body>
        {/* <blockquote className="blockquote mb-0">
          <p style={{ textAlign: "justify" }}>
          Hi everyone, I'm <span className="purple">Yash Bari </span>
            from <span className="purple"> Jogeshwari East, Mumbai, India.</span>
            <br />
            <br />
            I have a Bachelor’s degree in Computer Applications (BCA) and was previously working as a full-stack developer at DIGI-LATERAL Solutions.
            <br />
            <br />
            Right now, I'm on the lookout for a new job as a full-stack developer. 🚀
            <br />
            <br />
            Apart from coding, I enjoy
          </p>
          <ul>
            <li className="about-activity">
              <ImPointRight /> Playing Games🎮
            </li>
            <li className="about-activity">
              <ImPointRight /> Learning New Technology📚
            </li>
            <li className="about-activity">
              <ImPointRight /> Travelling✈️ 
            </li>
          </ul>

          <p style={{ color: "rgb(155 126 172)" }}>
            "Strive to build things that make a difference!"{" "}
          </p>
          <footer className="blockquote-footer">Yash</footer>
        </blockquote> */}
        <blockquote className="blockquote mb-0">
  <p style={{ textAlign: "justify" }}>
    Hi everyone, I'm <span className="purple">Yash Bari </span>
    from <span className="purple"> Jogeshwari East, Mumbai, India.</span>
    <br />
    <br />
    I have a Bachelor’s degree in Computer Applications (BCA) and was previously working as a full-stack developer.
    <br />
    <br />
    I am a highly skilled Full Stack & MERN Stack Developer with extensive experience designing, developing, and managing scalable web applications. Over the years, I have led numerous IT projects, improving system efficiency by 30% and boosting team productivity by 60% through strategic project management and innovative solutions. 🚀
    <br />
    <br />
    I am proficient in core programming languages including <span className="purple">JavaScript</span> and have a strong passion for building modern web technologies and products.
    <br />
    <br />
    My expertise lies in working with <span className="purple">Node.js, React.js, Next.js</span>, and other modern JavaScript frameworks. I have developed and delivered high-performance back-end systems, scalable APIs, and real-time applications, contributing to increased user engagement and operational efficiency.
    <br />
    <br />
    I enjoy creating innovative solutions across the full stack — from responsive frontends using React and Tailwind CSS to robust backends with Node.js, Express.js, MongoDB, and PostgreSQL. My projects range from logistics software and real-time chat applications to personal finance and e-commerce mobile apps.
  </p>
  <p>
    Apart from coding, I enjoy:
  </p>
  <ul>
    <li className="about-activity">
      <ImPointRight /> Playing Games🎮
    </li>
    <li className="about-activity">
      <ImPointRight /> Learning New Technology📚
    </li>
    <li className="about-activity">
      <ImPointRight /> Travelling✈️ 
    </li>
  </ul>

  <p style={{ color: "rgb(155 126 172)" }}>
    "Strive to build things that make a difference!"{" "}
  </p>
  <footer className="blockquote-footer">Yash</footer>
</blockquote>

      </Card.Body>
    </Card>
  );
}

export default AboutCard;
