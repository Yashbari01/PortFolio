import React from "react";
import Typewriter from "typewriter-effect";

function Type() {
  return (
    <Typewriter
      options={{
        strings: [
          "Software Developer",
          "Freelancer",
          "Frontend Developer",
          "Backend Developer",
          "MERN Stack Developer",
          "Full Stack Developer",
          "React.js Developer",
          "Node.js Developer",
          "UI/UX Enthusiast",
          "API Integration Specialist",
          "Open Source Contributor",
          "Problem Solver",
        ],
        autoStart: true,
        loop: true,
        deleteSpeed: 50,
      }}
    />
  );
}

export default Type;
