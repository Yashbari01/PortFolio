import React from "react";
import { Col, Row, OverlayTrigger, Tooltip } from "react-bootstrap";
import {
  SiVisualstudiocode, SiPostman, SiLinux, SiWindows11, SiVercel,
  SiNotepadplusplus, SiGithub, SiGitlab, SiNetlify, SiXampp,
  SiHeroku, SiMicrosoftedge, SiCodesandbox, SiIntellijidea,
  SiEclipseide,
  SiPycharm,
  SiJupyter,
} from "react-icons/si";
import { FaChrome } from "react-icons/fa";
import { DiApple } from "react-icons/di";

const tools = [
  { icon: <SiWindows11 />, name: "Windows" },
  { icon: <DiApple />, name: "Mac OS" },
  { icon: <SiLinux />, name: "Linux" },
  { icon: <SiVisualstudiocode />, name: "VS Code" },
  { icon: <SiNotepadplusplus />, name: "Notepad++" },
  { icon: <SiPostman />, name: "Postman" },
  { icon: <SiGithub />, name: "GitHub" },
  { icon: <SiGitlab />, name: "GitLab" },
  { icon: <SiVercel />, name: "Vercel" },
  { icon: <SiNetlify />, name: "Netlify" },
  { icon: <SiXampp />, name: "XAMPP" },
  { icon: <SiHeroku />, name: "Heroku" },
  { icon: <FaChrome />, name: "Chrome DevTools" },
  { icon: <SiMicrosoftedge />, name: "Microsoft Edge" },
  { icon: <SiCodesandbox />, name: "CodeSandbox" },
   // 🔹 Java & Python Platforms
  { icon: <SiIntellijidea />, name: "IntelliJ IDEA" },
  { icon: <SiEclipseide />, name: "Eclipse IDE" },
  { icon: <SiPycharm />, name: "PyCharm" },
  { icon: <SiJupyter />, name: "Jupyter Notebook" },
];

function Toolstack() {
  return (
    <Row style={{ justifyContent: "center", paddingBottom: "50px" }}>
      {tools.map((tool, index) => (
        <Col xs={4} md={2} key={index} className="tech-icons">
          <OverlayTrigger
            placement="top"
            overlay={<Tooltip id={`tooltip-${index}`}>{tool.name}</Tooltip>}
          >
            <span>{tool.icon}</span>
          </OverlayTrigger>
        </Col>
      ))}
    </Row>
  );
}

export default Toolstack;
